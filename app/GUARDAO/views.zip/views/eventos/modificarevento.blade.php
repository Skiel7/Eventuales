<html>
@extends('layouts.1')
<head>
	@include('includes.headME')
	
	@if(!Session::has('usuario_id'))
		@stop
		@else
	
	{{ HTML::script('js/datepicker.js') }}
	
	{{ HTML::style('css/datepicker.css') }}
	<script type="text/javascript" src="js/jquery.js"></script>
    <script src="https://maps.googleapis.com/maps/api/js?v=3.exp&signed_in=true"></script> 
	<!-- COSAS DEL MAPA-->
	
	<script type="text/javascript" src="js/jquery.js"></script>
    <script src="https://maps.googleapis.com/maps/api/js?v=3.exp&signed_in=true"></script> 
	<link href="../css/mapautilizado.css" rel="stylesheet">
	<script type="text/javascript" src="../js/jsmapaModificar.js"></script>
	
		
	
</head>
@section('content')
<div class="page-header">
    <div class="container" id="page">
		<h1>Modificar Evento</h1>
    </div>    
</div>
<div class="jumbotron">

	{{Form::open(array('method' => 'POST', 'class'=>'form-horizontal', 'action' =>'EventoController@modificarelevento' , 'role' => 'form'))}}
	<fieldset>
	
		<body>
			<div class="row">
				<div class="col-md-6">
					<input name="capturaevent" type="hidden" value="{{$eventomodid->id}}">				                                       
					<!--Nombre Evento-->
						
							<div class="form-group">
								{{Form::label('Nombre Evento')}}							
								{{Form::text('nombre',$eventomodid->nombre , array( 'class' => 'form-control'))}} <!--asi es para poder hacer lo mismo con el modificar-->
															
							</div>				  
													  
						<!--Fecha-->
							<div class="form-group">
								{{Form::label('Fecha')}}							
								{{ Form::input('date','fecha',$eventomodid->fecha ,array( 'date_format' => 'yyyy-mm-dd')) }}							
							</div>  
						<!--Hora-->
							<div class="form-group">
								{{Form::label('Hora')}}							
								{{ Form::input('time','hora',$eventomodid->hora,array( 'time_format' => 'HH:mm:ss')) }}						
							</div>						
						<!--Descripcion-->
							<div class="form-group">
								{{Form::label('Descripcion')}}
								
								{{Form::textarea('descripcion',$eventomodid->descripcion,array('class'=>'form-control'))}}
								
							</div>
							
							<div class="form-group"  >
								
								{{Form::label('Adultos')}}	
								
								<div>
								{{ Form::input('number','adultosmax',$eventomodid->adultosmax) }}						
								</div>
							</div>		
					
							<div class="form-group"  >
								{{Form::label('Menores')}}						
								<div>
								{{ Form::input('number','menoresmax', $eventomodid->menoresmax) }}	
								</div>
							</div>
	  
  
  
				</div>
			
  					<!--Mapa de Gmap-->                  
					<div class="col-md-6">
						<div>
						<input id="direccion" name="direccion" type="textbox" value="{{$eventomodid->direccion}}" title="Ingresar direccion. Ejemplo: bariloche moreno 40">
						<input type="button" value="Geocode" onclick="codeAddress()" title="Localiza la direccion en el mapa">
						</div>
						
						<div  id="map-canvas" ></div>	
							<!--campos donde guardamos los datos-->
						<div>
							<p></p>
						<p><label>Latitud: </label><input type="text" readonly name="lat" id="lat" value="{{$eventomodid->latitud}}"/></p>
						<p><label> Longitud:</label> <input type="text" readonly name="lng" id="long" value="{{$eventomodid->longitud}}"/></p>
						</div>
					</div>					
			</div>
			{{Form::submit('Modificar', array('class' => 'btn btn-success'))}}	
	</fieldset>
	{{Form::close()}}	
	</body>
</div>
	

				
@endif
@stop
</html>	

