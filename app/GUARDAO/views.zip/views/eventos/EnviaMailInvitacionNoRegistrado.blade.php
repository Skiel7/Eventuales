<html lang="en-US">
	<head>
		<meta charset="utf-8">
		<h2>Invitacion-Registro</h2>
	</head>
	<body>
		<p><!--Hola NombreDeInvitado ! : {{$nombre}}</p>
		<p>Has sido invitado al evento: NombreEvento  {{$email}}</p>
		<p>Ingresa a www.eventuales.esy.es/registro para registrarte y acceder al evento al que te han invitado!</p>
		<p>Mensaje:</p>
		{{$mensaje}}
		-->

		
	</body>
</html>