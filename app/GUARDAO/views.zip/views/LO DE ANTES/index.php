<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="../../favicon.ico">

    <title>Meating Inicio</title>

    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="css/StyleComun.css" rel="stylesheet">
    <link href="css/StyleIndex.css" rel="stylesheet">
  </head>
  <body>
	
  	<!--barra de menu-->
    <div class="navbar navbar-default navbar-fixed-top" role="navigation">
        <div class="container"><img class="navbar-brand" src="img/meatingLogo3.png"   HEIGHT="100px" ></img> <!style="width: 150px; height: auto;>
          <div class="navbar-header">
              <a class="navbar-brand">Meating</a>
          </div>
          <div class="navbar-collapse collapse">
            <ul class="nav navbar-nav">
              <li class="active"><a href="#">Inicio</a></li>
              <li><a href="QueEs.php">¿Que es Meating?</a></li>
              <li><a href="QuienesSomos.php">¿Quienes somos?</a></li> 
              <li><a href="Contacto.php">Contacto</a></li>           
            </ul>
            <ul class="nav navbar-nav navbar-right">
              <li><a href="Login.php">Inicio de Sesion</a></li> 
              <li><a href="Registro.php">Registrarse</a></li>
            </ul>
          </div><!--/.nav-collapse -->
        </div>
    </div>
    <!--le da el cuerpo al body (valga la redundancia)--> <!--modificado en el css box-shadow-->
    <div class="container"> 
    	<div id="SlideDeAsados" class="carousel slide" data-ride="carousel">
    <!-- Indicators -->
             <ol class="carousel-indicators">
                <li data-target="#SlideDeAsados" data-slide-to="0" class="active"></li>
                <li data-target="#SlideDeAsados" data-slide-to="1"></li>
                <li data-target="#SlideDeAsados" data-slide-to="2"></li>
            </ol>
    <!-- Wrapper for slides -->
            <div class="carousel-inner">
              <div class="item active">
                  <img src="img/Asado01.jpg">
                  <div class="carousel-caption">
                      ...
                  </div>
              </div>
              
            <div class="item">
                <img src="img/Asado02.jpg"  alt="...">
                <div class="carousel-caption">
                ...
                </div>
            </div>
            
            <div class="item">
                <img src="img/Asado03.jpg">
                <div class="carousel-caption">
                    ...
                </div>
            </div>
          </div>
  <!-- controles del slide (las flechas) -->
            <a class="left carousel-control" href="#SlideDeAsados" role="button" data-slide="prev">
            <span class="glyphicon glyphicon-chevron-left"></span></a>
            <a class="right carousel-control" href="#SlideDeAsados" role="button" data-slide="next">
            <span class="glyphicon glyphicon-chevron-right"></span></a>
        </div>
		<div class="row" align="center" >
			<h2><span class="label label-warning">ORGANIZÁ TU EVENTO EN 3 SIMPLES PASOS!!!</span></h2>			
		</div>
        <!--Cuadros de promocion*-->
        <div class="row">
        	<div class="col-sm-6 col-md-4">
    			<div class="thumbnail">
      				<img src="img/c1.png" alt="...">
      				<div class="caption" align="center">
        				<h3>ORGANIZÁ RAPIDO Y FACIL!</h3>
        				<p>Ahorrá tiempo! Porque con Meating calculamos todo y lo haces en un touch!</p>
        				<p><a href="Registro.php" class="btn btn-primary" role="button">Registrate Ahora!</a> </p>
      				</div>
    			</div>
  			</div>
            <div class="col-sm-6 col-md-4">
    			<div class="thumbnail">
      				<img src="img/members2 - copia.png" alt="...">
      				<div class="caption" align="center">
        				<h3>INVITA</h3>
        				<p>Invita a todas las personas que quieras porque tenemos el corazon gigante!!</p>
        				<p><a href="Registro.php" class="btn btn-primary" role="button">Invita amig@s!</a> </p>
      				</div>
    			</div>
  			</div>
            <div class="col-sm-6 col-md-4">
    			<div class="thumbnail">
      				<img src="img/c2menu-icon - copia.png"alt="...">
      				<div class="caption" align="center">
        				<h3>DISFRUTA</h3>
        				<p>El ultimo paso y el mejor! Que estas esperando?? Regístrate y SALUD!</p>
        				<p><a href="Registro.php" class="btn btn-primary" role="button">Comenzá a disfrutar!</a> </p>
      				</div>
    			</div>
  			</div>
		</div>
    </div>

    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>

  </body>
 

 <div id="footer">
		<!-- FOOTER -->
        <footer id="mainFooter">
            <div class="wrapped" align="center"> <!Anclamos un footer abajo del todo de la pagina>
                <p class="pull-right"><a id="goTop" href="#"><h3> ^ </h3></a></p> <!con ese icono nos lleva hacia arriba de la pagina>
                <p>© 2014 MEating   ·  <a href="ruta de privacidad y terminos">Privacidad y Términos</a> · Seguinos en <!no va a llevar a los links mencionados abajo a traves de los iconos-imagenes>
                	<a href="http://facebook.com"><img src="img/f1.png" height='30' width='70'></a> | 
					<a href="http://twitter.com"><img src="img/t1.png" height='30' width='70'></a> |
					<a href="http://plus.google.com/share"><img src="img/g1.png" height='30' width='70'></a>
					
                </p>
            </div>
        </footer>
 </div>
  
</html>
