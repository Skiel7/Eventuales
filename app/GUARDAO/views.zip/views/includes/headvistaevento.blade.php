<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="../../../favicon.ico">

    <title>EventualEs - Vista del evento</title>

	<!-- CARGAR EL Bootstrap -->

    <!-- Bootstrap core CSS -->
    <link href="../css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="../css/StyleComun.css" rel="stylesheet">
    <link href="../css/StyleIndex.css" rel="stylesheet">
	<link href="../css/vallenato.css" rel="stylesheet">
	
	<script src="//code.jquery.com/jquery-1.11.3.min.js"></script>
	<script src="//code.jquery.com/jquery-migrate-1.2.1.min.js"></script>
	
	
	<!-- COSAS DEL MAPA-->
	
	<script type="text/javascript" src="js/jquery.js"></script>
    <script src="https://maps.googleapis.com/maps/api/js?v=3.exp&signed_in=true"></script> 
	<link href="../css/mapautilizado.css" rel="stylesheet">
	<script type="text/javascript" src="../js/jsmapautilizado.js"></script>
		
	<!------------------------------------------------------------------>
		
			
			