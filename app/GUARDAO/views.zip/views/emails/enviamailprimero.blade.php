<html lang="en-US">
	<head>
		<meta charset="utf-8">
		<h2>Invitacion</h2>
	</head>
	<body>
		<p>Hola!  {{$nombremodal}} {{$apellidomodal}}</p>
		<p>Has sido invitado al evento: {{$nombreevento}}  </p>
		<p>Ingresa a www.eventuales.esy.es con tu nombre y contraseña para chequear tus eventos!</p>
		<p></p>
		
		

		
	</body>
</html>