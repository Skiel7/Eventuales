<html lang="en-US">
	<head>
		<meta charset="utf-8">
		<h2>TE HAS REGISTRADO EN EVENTUALES</h2>
	</head>
	<body>
		<p><h1>Nombre de registro: {{$nombre}} </h1></p>
		<p><h1>Email de registro: {{$email}}</h1></p>		
		<p><h2>Mensaje:</p>
		<p><h2>Bienvenido a nuestro sistema de organizador de eventos!</h2></p>		
		<p>Los datos para ingresar a su cuenta son: </p>
		<p> Usuario: {{$nombre}}  -  Contraseña: {{$password}} </p>
		
		<p>Gracias por utilizar nuestro servicio. </p>	

		
	</body>
</html>