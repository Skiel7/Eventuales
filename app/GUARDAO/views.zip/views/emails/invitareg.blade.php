<html lang="en-US">
	<head>
		<meta charset="utf-8">
		<h2>Has sido invitado a registrarte en Eventuales</h2>
	</head>
	<body>
		<p><h1>Hola {{$nombremodal}} {{$apellidomodal}}</h1></p>
		<p><h1>Has sido invitado a registrarte en nuestra web para organizar y participar de eventos.</h1></p>		
		<p><h1>Ingresa en www.eventuales.esy.es/registro .</h1></p>	

		
	</body>
</html>