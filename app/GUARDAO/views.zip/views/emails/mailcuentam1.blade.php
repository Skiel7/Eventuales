<html lang="en-US">
	<head>
		<meta charset="utf-8">
		<h2>Cuentas</h2>
	</head>
	<body>
		<p>Hola!  {{$nombre}} </p>
		<p>Usted se encuentra confirmado en el evento: {{$nombreevento}}  </p>
		<p>El metodo elegido por el organizador para las cuentas es: {{$nombremetodo}} </p>
		<p>Las cuentas son las siguientes: </p>
		<p>El costo total que debe abonar es: {{$sale}}</p>
		<p>Usted gastó: {{$gastaste}}</p>
		
		<p>BALANCE: {{$balance}}</p>
		<p>**Si su balance es positivo, debe solicitar el dinero al organizador.**</p>
		<p>*Si su balance es negativo, usted DEBE entregar el valor correspondiente al organizador*</p>
		<p></p>
		<p></p>
		<p>Muchas Gracias por utilizar nuestros servicios.  -  www.eventuales.esy.es -</p>
		

		
	</body>
</html>