<html lang="en-US">
	<head>
		<meta charset="utf-8">
		<h2>Recordatorio de Contraseña</h2>
	</head>
	<body>
		
		<p>Los datos para ingresar a su cuenta son: </p>
		<p> Usuario: {{$nombre}}  -  Contraseña: {{$password}} </p>
		
		<p>Gracias por utilizar nuestro servicio. www.eventuales.esy.es </p>	

		
	</body>
</html>