<html lang="en-US">
	<head>
		<meta charset="utf-8">
	</head>
	<body>
		<h2>Recordatorio de	password</h2>

		<div>
			<p>Nombre del contacto: {{$nombre}}</p>
			<p>Email del contacto: {{$email}}</p>
			<p>Password:{{$password}}</p>
		</div>
	</body>
</html>