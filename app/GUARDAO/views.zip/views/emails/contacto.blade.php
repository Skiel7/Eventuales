<html lang="en-US">
	<head>
		<meta charset="utf-8">
		<h2>Contacto</h2>
	</head>
	<body>
		<p>Nombre del contacto: {{$nombre}}</p>
		<p>Email del contacto: {{$email}}</p>
		<p>Asunto:{{$asunto}}</p>
		<p>Mensaje:</p>
		{{$mensaje}}
		

		
	</body>
</html>