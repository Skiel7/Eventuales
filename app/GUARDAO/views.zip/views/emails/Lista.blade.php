<html lang="en-US">
	<head>
		<meta charset="utf-8">
		<h2>Lista de items</h2>
	</head>
	<body>
		<p>  {{$msg}} </p>
		
		

		
	</body>
</html>