
			    var ultimoAcordeonAbierto = 0;
				$( "#costofijoinvitado1" ).click(function() {
					if((ultimoAcordeonAbierto != 0) && (ultimoAcordeonAbierto != $('#costofijoinvitado1'))){
					   ultimoAcordeonAbierto.click(); 
				    }
				    ultimoAcordeonAbierto = $('#costofijoinvitado1');
				  $( "#costofijoinvitado2" ).toggle(  );
				  
				});
				$( "#costofijo1" ).click(function() {
					if((ultimoAcordeonAbierto != 0) && (ultimoAcordeonAbierto != $('#costofijo1'))){
					   ultimoAcordeonAbierto.click(); 
				    }
				    ultimoAcordeonAbierto = $('#costofijo1');
				  $( "#costofijo2" ).toggle(  );
				  
				});
				$( "#division1" ).click(function() {
					if((ultimoAcordeonAbierto != 0) && (ultimoAcordeonAbierto != $('#division1'))){
					   ultimoAcordeonAbierto.click(); 
				    }
				    ultimoAcordeonAbierto = $('#division1');
				  $( "#division2" ).toggle(  );
				  
				});
				$( "#divisionasistentegastado1" ).click(function() {
					if((ultimoAcordeonAbierto != 0) && (ultimoAcordeonAbierto != $('#divisionasistentegastado1'))){
						   ultimoAcordeonAbierto.click(); 
						}
						ultimoAcordeonAbierto = $('#divisionasistentegastado1');
				  $( "#divisionasistentegastado2" ).toggle(  );
				  
				});
				$( "#divisiongastado1" ).click(function() {
					if((ultimoAcordeonAbierto != 0) && (ultimoAcordeonAbierto != $('#divisiongastado1'))){
							   ultimoAcordeonAbierto.click(); 
							}
							ultimoAcordeonAbierto = $('#divisiongastado1');
					
				  $( "#divisiongastado2" ).toggle(  );
				  
				});
				$( "#divisionasistentefijo1" ).click(function() {
					if((ultimoAcordeonAbierto != 0) && (ultimoAcordeonAbierto != $('#divisionasistentefijo1'))){
					   ultimoAcordeonAbierto.click(); 
				    }
				    ultimoAcordeonAbierto = $('#divisionasistentefijo1');
				  $( "#divisionasistentefijo2" ).toggle(  );
				  
				});
		
	